#!/bin/bash

flex lexer.l
bison -d arun_parser.y
gcc y.tab.c lex.yy.c


a.exe<assign-1_test-1_invalid.c>output6.txt
a.exe<assign-1_test-2_invalid.c>output7.txt
a.exe<assignment-1_nested_do_while_valid.c>output8.txt
a.exe<assignment-1_nested_for_valid.c>output9.txt
a.exe<assignment-1_simple_do_while_valid.c>output10.txt
a.exe<assignment-1_simple_for_valid.c>output11.txt

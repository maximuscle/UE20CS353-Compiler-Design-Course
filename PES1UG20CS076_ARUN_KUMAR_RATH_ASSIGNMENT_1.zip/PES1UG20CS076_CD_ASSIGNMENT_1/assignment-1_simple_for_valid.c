#include <stdio.h>

int main()
{
	int a,b=6; //ffffffffffffffffffffffffffffffff
	char c[5]; 
	a = 5 + 3;
	b = ++a; 
	for(int i = 0;i<5;i++) 
	{
		c[i] = i;
	}
}
